# Jatin-Ai

Jatin AI assistant backend.

## Run locally

1. Install Node.js 18+.
2. Run `npm install`.
3. Create a `.env` file from `.env.example`.
4. Put your OpenAI API key in `.env`.
5. Run `npm start`.

## Endpoints

- `GET /` - basic status
- `GET /health` - health/configuration check
- `POST /chat` - send `{ "message": "Hello" }`

Never commit your real API key to GitHub.
